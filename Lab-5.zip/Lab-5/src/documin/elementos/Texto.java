package documin.elementos;

public class Texto extends ElementoAbstract{

    public Texto(String propiedades, int valor) {
        super(propiedades, valor);
    }
}
