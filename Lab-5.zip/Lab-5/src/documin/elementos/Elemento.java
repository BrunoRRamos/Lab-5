package documin.elementos;

public interface Elemento {
    public String getPropiedades();
    public int getValor();
}
