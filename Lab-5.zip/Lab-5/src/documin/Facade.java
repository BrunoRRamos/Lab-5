package documin;

// import documin.documento.DocumentoController

public class Facade {

    // private DocumentoController documentoController;

    public Facade() {
        // // exemplo de chamada no construtor:
        // this.documentoController = new DocumentoController();
    }

    public boolean criarDocumento(String titulo) {
        // // exemplo de chamada a ser implementado
        //  return this.documentoController.criarDocumento(titulo);
        return false;
    }

}

